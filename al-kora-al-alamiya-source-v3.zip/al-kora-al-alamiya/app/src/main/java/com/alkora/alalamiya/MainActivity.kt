package com.alkora.alalamiya

import android.os.Bundle
import android.text.Html
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080D17)
private val Panel = Color(0xFF111A2A)
private val Panel2 = Color(0xFF18243A)
private val Gold = Color(0xFFFFC857)
private val Muted = Color(0xFF9AA8BD)
private val White = Color(0xFFF5F7FB)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GlobalBallApp() }
    }
}

data class TabItem(val title: String, val icon: ImageVector)
private val tabs = listOf(
    TabItem("المباريات القادمة", Icons.Default.SportsSoccer),
    TabItem("الأخبار", Icons.Default.Article),
    TabItem("البطولات", Icons.Default.EmojiEvents),
    TabItem("الدوريات", Icons.Default.Leaderboard)
)

private val competitions = listOf(
"دوري أبطال أوروبا", "دوري نجوم العراق", "الدوري الإنجليزي", "كأس السوبر الإسباني", "الدوري الإسباني", "الدوري الإيطالي", "الدوري الألماني", "الدوري الفرنسي", "كأس إنتركونتيننتال", "الدوري الأوروبي", "دوري المؤتمر الأوروبي", "كأس السوبر السعودي", "دوري روشن السعودي", "كأس خادم الحرمين الشريفين", "كأس السوبر الأفريقي", "دوري أبطال أفريقيا", "كأس الكونفيدرالية", "دوري ORA", "دوري أبطال آسيا للنخبة", "دوري أبطال آسيا 2", "دوري أبطال الخليج", "الدوري التركي", "الدوري البرتغالي الممتاز", "الدوري البرازيلي", "كأس الاتحاد الإنجليزي", "كأس الرابطة الإنجليزية", "كأس ملك إسبانيا", "كأس إيطاليا", "كأس ألمانيا", "كأس مصر", "كأس الرابطة البرتغالية", "كأس عاصمة مصر", "البطولة الوطنية المغربية", "الرابطة المحترفة الجزائرية", "الرابطة التونسية لكرة القدم", "السوبر القطري الإماراتي", "دوري نجوم بنك الدوحة", "كأس قطر", "كأس QSL", "كأس سوبر إعمار", "دوري أدنوك للمحترفين", "كأس مصرف أبوظبي", "كأس رئيس الدولة", "الدوري الأردني", "كأس الأردن", "الدوري السوداني الممتاز", "دوري الدرجة الأولى السعودي", "المباريات الودية للأندية", "كأس آسيا", "كأس الخليج العربي", "كأس الخليج تحت 17 سنة", "كأس العالم", "كأس العالم تحت 17 سنة", "دوري الأمم الأوروبية", "تصفيات كأس أمم أفريقيا", "مباراة ودية"
)

@Composable fun GlobalBallApp() {
    val context = LocalContext.current
    val preferences = remember { context.getSharedPreferences("alkora_preferences", android.content.Context.MODE_PRIVATE) }
    var selected by remember { mutableIntStateOf(1) }
    var selectedCompetition by remember { mutableStateOf<String?>(null) }
    var liked by remember { mutableStateOf(preferences.getStringSet("liked_articles", emptySet())?.toSet() ?: emptySet()) }
    var saved by remember { mutableStateOf(preferences.getStringSet("saved_articles", emptySet())?.toSet() ?: emptySet()) }
    var searchVisible by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Gold, onBackground = White, onSurface = White)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Color(0xFF0D1422), contentColor = White) {
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(selected = selected == index, onClick = { selected = index; selectedCompetition = null },
                        icon = { Icon(tab.icon, contentDescription = tab.title) }, label = { Text(tab.title, fontSize = 10.sp, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Gold, selectedTextColor = Gold, indicatorColor = Panel2, unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).background(Bg)) {
                Header(onSearch = { searchVisible = !searchVisible; if (searchVisible) selected = 2 else searchQuery = "" })
                if (searchVisible) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
                        singleLine = true,
                        placeholder = { Text("ابحث عن بطولة أو دوري...", color = Muted) },
                        leadingIcon = { Icon(Icons.Default.Search, null, tint = Gold) },
                        trailingIcon = { IconButton(onClick = { searchQuery = "" }) { Icon(Icons.Default.Close, "مسح", tint = Muted) } },
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = White, unfocusedTextColor = White, focusedBorderColor = Gold, unfocusedBorderColor = Panel2, cursorColor = Gold)
                    )
                }
                when (selected) {
                    0 -> FixturesScreen()
                    1 -> NewsScreen(
                        liked,
                        { id -> val next = if (id in liked) liked - id else liked + id; liked = next; preferences.edit().putStringSet("liked_articles", next).apply() },
                        saved,
                        { id -> val next = if (id in saved) saved - id else saved + id; saved = next; preferences.edit().putStringSet("saved_articles", next).apply() }
                    )
                    2 -> CompetitionsScreen(selectedCompetition, { selectedCompetition = it }, searchQuery)
                    3 -> LeaguesScreen(searchQuery)
                }
            }
        }
    }
}

@Composable private fun Header(onSearch: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color(0xFF0D1422)).padding(horizontal = 18.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).background(Gold, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.SportsSoccer, null, tint = Bg, modifier = Modifier.size(26.dp)) }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) { Text("الكرة العالمية", fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, color = White); Text("كل كرة القدم في مكان واحد", fontSize = 11.sp, color = Muted) }
        IconButton(onClick = onSearch) { Icon(Icons.Default.Search, "بحث", tint = White) }
    }
}

@Composable private fun SectionTitle(title: String, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = White)
        if (subtitle != null) Text(subtitle, fontSize = 12.sp, color = Muted)
    }
}

private data class NewsArticle(val title: String, val summary: String, val published: String, val link: String)
private data class LiveMatch(val competition: String, val home: String, val away: String, val date: String, val status: String, val score: String)

private fun fetchNews(): List<NewsArticle> {
    val url = URL("https://news.google.com/rss/search?q=كرة+قدم+OR+انتقالات+كرة+القدم&hl=ar&gl=IQ&ceid=IQ:ar")
    val c = (url.openConnection() as HttpURLConnection).apply { connectTimeout = 12000; readTimeout = 12000; setRequestProperty("User-Agent", "AlKoraAlAlamiya/1.0") }
    try {
        val parser = XmlPullParserFactory.newInstance().newPullParser()
        c.inputStream.use { parser.setInput(it, "UTF-8")
            val out = mutableListOf<NewsArticle>(); var event = parser.eventType
            var inItem = false; var tag = ""; var title = ""; var desc = ""; var date = ""; var link = ""
            while (event != XmlPullParser.END_DOCUMENT && out.size < 30) {
                when (event) {
                    XmlPullParser.START_TAG -> { tag = parser.name.lowercase(); if (tag == "item") { inItem = true; title=""; desc=""; date=""; link="" } }
                    XmlPullParser.TEXT -> if (inItem) when(tag) { "title" -> title += parser.text; "description" -> desc += parser.text; "pubdate" -> date += parser.text; "link" -> link += parser.text }
                    XmlPullParser.END_TAG -> if (parser.name.equals("item", true)) {
                        if (title.isNotBlank()) out.add(NewsArticle(cleanHtml(title), cleanHtml(desc), date.trim(), link.trim()))
                        inItem = false
                    }
                }; event = parser.next()
            }; out
        }
    } finally { c.disconnect() }
}

private fun cleanHtml(s: String): String = Html.fromHtml(s, Html.FROM_HTML_MODE_COMPACT).toString().replace("\\s+".toRegex(), " ").trim()
private fun fetchMatches(): List<LiveMatch> {
    val url = URL("https://sportscore.com/api/widget/matches/?sport=football&limit=30&src=alkora-alalamiya")
    val c = (url.openConnection() as HttpURLConnection).apply { connectTimeout=12000; readTimeout=12000; setRequestProperty("User-Agent", "AlKoraAlAlamiya/1.0") }
    try {
        val root = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        fun findMatches(node: JSONObject, depth: Int = 0): JSONArray? {
            if (depth > 4) return null
            for (key in listOf("matches", "events", "fixtures", "results", "data")) {
                node.optJSONArray(key)?.let { return it }
            }
            for (key in listOf("data", "response", "result")) {
                val child = node.optJSONObject(key) ?: continue
                findMatches(child, depth + 1)?.let { return it }
            }
            return null
        }
        val arr = findMatches(root) ?: JSONArray()
        val out = mutableListOf<LiveMatch>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            fun value(vararg keys: String): String {
                for (k in keys) { val v=o.opt(k); if (v is String && v.isNotBlank()) return v; if (v is JSONObject) { val n=v.optString("name", v.optString("team_name", "")); if(n.isNotBlank()) return n } }
                return ""
            }
            val home=value("home_team","homeTeam","home","team_home","localteam")
            val away=value("away_team","awayTeam","away","team_away","visitorteam")
            if (home.isBlank() || away.isBlank()) continue
            val comp=value("competition","league","tournament","competition_name")
            val date=value("date","start_time","datetime","kickoff","match_date")
            val status=value("status","state","time_status")
            val hs=value("home_score","homeScore","score_home"); val ascore=value("away_score","awayScore","score_away")
            val score=if(hs.isNotBlank() || ascore.isNotBlank()) "$hs - $ascore" else "لم تبدأ"
            out.add(LiveMatch(comp.ifBlank { "كرة القدم" },home,away,date,status,score))
        }
        out
    } finally { c.disconnect() }
}

@Composable private fun NewsScreen(liked: Set<String>, onLike: (String) -> Unit, saved: Set<String>, onSave: (String) -> Unit) {
    val context = LocalContext.current
    var articles by remember { mutableStateOf<List<NewsArticle>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf(false) }
    var opened by remember { mutableStateOf<NewsArticle?>(null) }
    var showSaved by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) { try { articles = withContext(Dispatchers.IO) { fetchNews() }; error = articles.isEmpty() } catch (_: Exception) { error=true } finally { loading=false }; delay(15 * 60 * 1000L) } }
    LazyColumn(contentPadding = PaddingValues(bottom = 18.dp)) {
        item {
            Column(Modifier.fillMaxWidth()) {
                SectionTitle("آخر الأخبار", "عناوين عربية مجمعة تلقائياً من أخبار كرة القدم")
                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !showSaved, onClick = { showSaved = false }, label = { Text("كل الأخبار") }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Panel2, selectedLabelColor = Gold))
                    FilterChip(selected = showSaved, onClick = { showSaved = true }, label = { Text("المحفوظة (${saved.size})") }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Panel2, selectedLabelColor = Gold))
                }
            }
        }
        if (loading) item { InfoCard("جارٍ تحديث الأخبار", "يتم جلب أحدث العناوين من موجز الأخبار العربي.", Icons.Default.Sync) }
        if (error) item { InfoCard("تعذر تحديث الأخبار", "تحقق من اتصال الإنترنت ثم أعد فتح التطبيق. لا نعرض أخباراً مختلقة عند تعطل المصدر.", Icons.Default.WifiOff) }
        items(if (showSaved) articles.filter { it.hashCode().toString() in saved } else articles) { article ->
            Card(Modifier.fillMaxWidth().padding(horizontal=14.dp, vertical=6.dp).clickable { opened=article }, colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.Public, null, tint=Gold); Spacer(Modifier.width(8.dp)); Text("أخبار كرة القدم", color=Gold, fontSize=11.sp); Spacer(Modifier.weight(1f)); Text(article.published.take(22), color=Muted, fontSize=10.sp) }
                    Spacer(Modifier.height(10.dp)); Text(article.title, color=White, fontSize=16.sp, fontWeight=FontWeight.Bold, lineHeight=23.sp)
                    if(article.summary.isNotBlank()) { Spacer(Modifier.height(7.dp)); Text(article.summary.take(320), color=Muted, fontSize=12.sp, lineHeight=19.sp) }
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text("تفاصيل الخبر", color=Gold, fontSize=11.sp, modifier=Modifier.weight(1f))
                        TextButton(onClick={onLike(article.hashCode().toString())}) {
                            Icon(if (article.hashCode().toString() in liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (article.hashCode().toString() in liked) Color(0xFFFF657A) else Muted)
                            Text("إعجاب", color = White)
                        }
                        IconButton(onClick = { onSave(article.hashCode().toString()) }) {
                            Icon(if (article.hashCode().toString() in saved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, null, tint = Gold)
                        }
                        IconButton(onClick = {
                            val shareText = listOf(article.title, article.link).filter { it.isNotBlank() }.joinToString("\n")
                            val sendIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, shareText) }
                            context.startActivity(android.content.Intent.createChooser(sendIntent, "مشاركة الخبر"))
                        }) { Icon(Icons.Default.Share, "مشاركة", tint = Muted) }
                    }
                }
            }
        }
        if (showSaved && articles.none { it.hashCode().toString() in saved }) {
            item { InfoCard("لا توجد أخبار محفوظة حالياً", "اضغط على علامة الحفظ في أي خبر لإضافته إلى هذه القائمة.", Icons.Default.BookmarkBorder) }
        }
        item { Text("موجز العناوين: Google News · يتم الاحتفاظ برابط الناشر داخلياً ولا يعاد نشر نص المقال المحمي.", color=Muted, fontSize=10.sp, modifier=Modifier.padding(16.dp)) }
    }
    opened?.let { a -> AlertDialog(onDismissRequest={opened=null}, containerColor=Panel, title={Text(a.title,color=White)}, text={Column { Text(a.published,color=Gold,fontSize=11.sp); Spacer(Modifier.height(8.dp)); Text(a.summary.ifBlank { "لا يوفر الموجز نص المقال الكامل. يعرض التطبيق العنوان والملخص المتاحين فقط." },color=White) }}, confirmButton={TextButton(onClick={opened=null}) { Text("إغلاق",color=Gold) }}) }
}

@Composable private fun FixturesScreen() {
    var matches by remember { mutableStateOf<List<LiveMatch>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var failed by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) { try { matches=withContext(Dispatchers.IO) { fetchMatches() }; failed=matches.isEmpty() } catch (_: Exception) { failed=true } finally { loading=false }; delay(5 * 60 * 1000L) } }
    LazyColumn(contentPadding=PaddingValues(bottom=18.dp)) {
        item { SectionTitle("المباريات القادمة", "بيانات مباريات مباشرة من مزود رياضي مجاني") }
        if(loading) item { InfoCard("جارٍ تحميل المباريات", "يتم الاتصال بمصدر النتائج والمواعيد.", Icons.Default.Sync) }
        if(failed) item { InfoCard("لم تصل بيانات المباريات", "قد يكون المصدر لا يعرض مباريات حالياً أو تعذر الاتصال. أعد المحاولة لاحقاً.", Icons.Default.WifiOff) }
        items(matches) { m ->
            Card(Modifier.fillMaxWidth().padding(horizontal=14.dp, vertical=6.dp), colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(17.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Text(m.competition,color=Gold,fontSize=11.sp,fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(10.dp)); Row(verticalAlignment=Alignment.CenterVertically) { Text(m.home,Modifier.weight(1f),color=White,fontWeight=FontWeight.Bold); Text(m.score,color=Gold,fontSize=17.sp,fontWeight=FontWeight.ExtraBold); Text(m.away,Modifier.weight(1f),color=White,fontWeight=FontWeight.Bold,textAlign=TextAlign.End) }
                    Spacer(Modifier.height(8.dp)); Text(listOf(m.date,m.status).filter{it.isNotBlank()}.joinToString(" · "),color=Muted,fontSize=11.sp)
                }
            }
        }
        item { Text("مصدر بيانات المباريات: SportScore · sportscore.com", color=Muted, fontSize=10.sp, modifier=Modifier.padding(16.dp)) }
        item { SectionTitle("إحصاءات المباريات", "تتطلب تفاصيل المباراة وتغطية البطولة من المزود") }
        item { listOf("التشكيلات الرسمية والمتوقعة", "الاستحواذ والتسديدات والركنيات", "البطاقات والتبديلات وأحداث المباراة", "ترتيب الفريقين والمواجهات السابقة", "تقييمات اللاعبين وإحصاءاتهم").forEach { FeatureRow(it) } }
    }
}

@Composable private fun InfoCard(title: String, body: String, icon: ImageVector) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(17.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Gold, modifier = Modifier.size(32.dp)); Spacer(Modifier.width(13.dp)); Column { Text(title, color = White, fontWeight = FontWeight.Bold); Spacer(Modifier.height(4.dp)); Text(body, color = Muted, fontSize = 12.sp, lineHeight = 18.sp) } }
    }
}
@Composable private fun FeatureRow(text: String) { Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.CheckCircle, null, tint = Gold, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(10.dp)); Text(text, color = White, fontSize = 14.sp) } }


private fun isLeagueName(name: String): Boolean {
    val cupWords = listOf("كأس", "السوبر", "مباراة ودية", "تصفيات", "دوري أبطال", "دوري المؤتمر", "دوري الأمم")
    return cupWords.none { name.contains(it) }
}

@Composable private fun CompetitionsScreen(
    selectedCompetition: String?,
    onSelect: (String?) -> Unit,
    query: String
) {
    val filtered = remember(query) { competitions.filter { it.contains(query.trim(), ignoreCase = true) } }
    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item { SectionTitle("البطولات", "${competitions.size} بطولة ومسابقة ضمن قائمة التطبيق") }
        if (selectedCompetition == null) {
            items(filtered) { competition ->
                Card(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp).clickable { onSelect(competition) },
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(15.dp)
                ) {
                    Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).background(Panel2, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.EmojiEvents, null, tint = Gold)
                        }
                        Spacer(Modifier.width(12.dp))
                        Text(competition, Modifier.weight(1f), color = White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Icon(Icons.Default.ChevronLeft, null, tint = Muted)
                    }
                }
            }
            if (filtered.isEmpty()) item { InfoCard("لا توجد نتائج", "جرّب كتابة اسم البطولة بطريقة أخرى.", Icons.Default.SearchOff) }
        }
    }
    selectedCompetition?.let { name ->
        AlertDialog(
            onDismissRequest = { onSelect(null) },
            containerColor = Panel,
            title = { Text(name, color = White, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("صفحة البطولة", color = Gold, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("تمت إضافة البطولة إلى دليل الكرة العالمية. جداول الترتيب والهدافون والنتائج التفصيلية ستظهر عند ربط مصدر بيانات موثوق يدعم هذه المسابقة.", color = Muted, lineHeight = 20.sp)
                    Spacer(Modifier.height(12.dp))
                    listOf("جدول الترتيب", "المباريات والنتائج", "الهدافون وصنّاع الأهداف", "إحصائيات البطولة").forEach { FeatureRow(it) }
                }
            },
            confirmButton = { TextButton(onClick = { onSelect(null) }) { Text("رجوع", color = Gold) } }
        )
    }
}

@Composable private fun LeaguesScreen(query: String) {
    val leagues = remember(query) { competitions.filter(::isLeagueName).filter { it.contains(query.trim(), ignoreCase = true) } }
    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item { SectionTitle("الدوريات", "استعرض الدوريات المحلية والقارية والعالمية") }
        items(leagues) { league ->
            Card(
                Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp),
                colors = CardDefaults.cardColors(containerColor = Panel),
                shape = RoundedCornerShape(15.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Leaderboard, null, tint = Gold, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) {
                        Text(league, color = White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("الدوري · صفحة البيانات قيد الربط", color = Muted, fontSize = 11.sp)
                    }
                }
            }
        }
        if (leagues.isEmpty()) item { InfoCard("لا توجد نتائج", "لم نعثر على دوري بهذا الاسم.", Icons.Default.SearchOff) }
    }
}
